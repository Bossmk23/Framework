# /configs/config.py

class Config:
    # Dataset configuration
    DATA_PATH = "data/dataset.csv"
    PROCESSED_DATA_PATH = "data/processed_dataset.pkl"

    # Model configuration
    MODEL_SAVE_PATH = "models/trained_model.pkl"
    RANDOM_SEED = 42
    TEST_SIZE = 0.2

    # Training configuration
    BATCH_SIZE = 32
    EPOCHS = 10
    LEARNING_RATE = 0.001
