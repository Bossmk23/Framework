import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from models.cnn_model import SampleModel
from datasets.image_dataset import SampleDataset
from trainers.cnn_trainer import SampleTrainer

def main():
    # Initialize dataset
    dataset = SampleDataset()
    train_loader, test_loader = dataset.load_data()

    # Initialize model
    model = SampleModel()
    model.build()

    # Initialize trainer with model and dataset loaders
    trainer = SampleTrainer(model, train_loader, test_loader)

    # Start training, evaluation, or full pipeline
    trainer.run()

if __name__ == "__main__":
    main()

