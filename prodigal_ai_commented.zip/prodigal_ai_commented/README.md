# Prodigal AI Framework

## 📁 Folder Structure

- `core/`: Abstract base classes for Model, Dataset, and Trainer.
- `models/`: Contains model implementations like CNN, RNN, etc.
- `datasets/`: Contains data loading and preprocessing logic.
- `trainers/`: Orchestrates training/evaluation using models and datasets.
- `utils/`: Helper functions (logging, metrics, etc.)
- `configs/`: Configuration files for experiments.
- `main.py`: Entry point to run the training or inference.

## ✅ Principles Used

- **Separation of Concerns**
- **Reusability**
- **Modularity**
- **Scalability**

## 🧱 Base Modules

- `BaseModel`: Defines `build()`, `forward()`, `save()`, `load()`
- `BaseDataset`: Defines `load_data()`, `preprocess()`
- `BaseTrainer`: Defines `train()`, `evaluate()`, `run()`

This architecture ensures a plug-and-play approach to building AI systems.
#how to run
pip install -r requirements.txt
python main.py 
